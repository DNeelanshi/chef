import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditstaffPage } from './editstaff';

@NgModule({
  declarations: [
    EditstaffPage,
  ],
  imports: [
    IonicPageModule.forChild(EditstaffPage),
  ],
})
export class EditstaffPageModule {}
